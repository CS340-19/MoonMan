package game.backend;

//creates enum type to identify player or enemy
public enum ID {
	
	Player(),
	Enemy(), 
	Floor();
	
}
