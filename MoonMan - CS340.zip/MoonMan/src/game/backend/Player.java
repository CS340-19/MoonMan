package game.backend;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Player extends GameObject {
	
	public static final int WIDTH = 640, HEIGHT = WIDTH / 12 * 9;	
	Random r = new Random();
	
	public Player(int x, int y, ID id) {
		super(x, y, id);
		
		velX = (r.nextInt(5)+1); 
		velY = (r.nextInt(5)+1);
	}
	
	public void tick() {
		x += velX;
		y += velY;
		if(x > WIDTH) {
			x = 0;
		}
		if(y > HEIGHT) {
			y = 0;
		}
	}
	
	public void render(Graphics g) {
		g.setColor(Color.orange);
		g.fillRect(x, y, 2, 2);
	}
	
}
