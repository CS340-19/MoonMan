package game.backend;
import java.awt.Graphics;
import java.util.LinkedList;

//Loops through all objects in game, updates them then renders to the screen
public class Handler {
	
	//make linked list to hold game objects
	LinkedList<GameObject> objects = new LinkedList<GameObject>();
	
	//loops through list
	public void tick() {
		for(int i = 0; i < objects.size(); i++) {
			GameObject tempObject = objects.get(i);
			
			tempObject.tick();
		}
	}
	public void render(Graphics g) {
		for(int i = 0; i < objects.size(); i++) {
			GameObject tempObject = objects.get(i);
			
			tempObject.render(g);
		}
	}
	
	public void addObject(GameObject object) {
		this.objects.add(object);
	}
	
	public void removeObject(GameObject object) {
		this.objects.remove(object);
	}
	
}